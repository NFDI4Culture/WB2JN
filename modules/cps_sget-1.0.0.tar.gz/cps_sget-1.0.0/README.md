# CPS Selenium GET

This is a simple tool to fetch a page using selenium.

GOTO https://wiki.kewl.org/projects:sget
